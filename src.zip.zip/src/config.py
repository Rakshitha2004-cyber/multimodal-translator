# config.py
# config.py

from deep_translator import GoogleTranslator


def build_supported_languages():
    """
    Ask deep_translator (Google Translate) for ALL supported languages
    and convert them into our internal format.

    Result example:
    {
        "English": {"code": "en"},
        "Hindi":   {"code": "hi"},
        ...
    }
    """
    # returns dict like {"english": "en", "hindi": "hi", ...}
    langs = GoogleTranslator().get_supported_languages(as_dict=True)

    supported = {}
    for name_lower, code in langs.items():
        # Title-case the name for display, e.g. "english" -> "English"
        display_name = name_lower.title()
        supported[display_name] = {"code": code}

    return supported


# This now contains 100+ languages supported by Google Translate
SUPPORTED_LANGUAGES = build_supported_languages()
