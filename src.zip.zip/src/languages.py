# languages.py
# languages.py

from config import SUPPORTED_LANGUAGES


def get_lang_code(lang_name: str) -> str:
    return SUPPORTED_LANGUAGES[lang_name]["code"]


# -------- For text translation (deep-translator / Google) --------

def code_for_googletrans(lang_name: str) -> str:
    return get_lang_code(lang_name)


# -------- For gTTS (text-to-speech) --------
# Note: gTTS does NOT support all 100+ languages; if unsupported it will raise
# an error, which we catch in main_app and show a message.

def code_for_gtts(lang_name: str) -> str:
    return get_lang_code(lang_name)


# -------- For EasyOCR (image OCR) --------
# In reality EasyOCR supports ~80+ languages; you may later limit this list.
# For now we reuse the same code and rely on you choosing OCR-supported langs.

def code_for_easyocr(lang_name: str) -> str:
    return get_lang_code(lang_name)


# -------- For SpeechRecognition (mic -> text) --------
# Only these languages are guaranteed to work with microphone STT.
# Other languages STILL work for text & image translation.

_SR_LANG_MAP = {
    "English": "en-IN",
    "Hindi": "hi-IN",
    "Kannada": "kn-IN",
    "Tamil": "ta-IN",
    "Telugu": "te-IN",
    "Malayalam": "ml-IN",
    "Marathi": "mr-IN",
    "Gujarati": "gu-IN",
    "Bengali": "bn-IN",
    "Spanish": "es-ES",
    "French": "fr-FR",
    "German": "de-DE",
    "Arabic": "ar-SA",
    "Chinese (Simplified)": "zh-CN",
    "Japanese": "ja-JP",
    "Korean": "ko-KR",
}


def code_for_sr(lang_name: str) -> str:
    # default to English India if not found
    return _SR_LANG_MAP.get(lang_name, "en-IN")


def has_sr_support(lang_name: str) -> bool:
    return lang_name in _SR_LANG_MAP
