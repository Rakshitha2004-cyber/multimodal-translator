# ocr.py

import easyocr
import numpy as np
from PIL import Image
from languages import code_for_easyocr

# Cache OCR readers so they are not reloaded every time
_cached_readers = {}

def get_reader(language_name: str):
    lang_code = code_for_easyocr(language_name)
    if lang_code not in _cached_readers:
        _cached_readers[lang_code] = easyocr.Reader([lang_code], gpu=False)
    return _cached_readers[lang_code]

def ocr_image(image: Image.Image, language_name: str):
    """
    Extract text from an image using EasyOCR.
    Returns: (extracted_text, raw_result)
    """
    reader = get_reader(language_name)

    img_np = np.array(image)
    result = reader.readtext(img_np, detail=1)  # list of (bbox, text, confidence)

    extracted_texts = []
    for bbox, text, conf in result:
        if conf > 0.4:  # ignore very low-confidence text
            extracted_texts.append(text)

    extracted_text = "\n".join(extracted_texts)
    return extracted_text, result

