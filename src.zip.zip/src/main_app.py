# main_app.py
# main_app.py

import streamlit as st
from utils import get_language_list
from stt import speech_to_text
from translate import translate_text
from tts import text_to_speech_file, cleanup_temp_file
from ocr import ocr_image
from PIL import Image
import tempfile
from st_audiorec import st_audiorec
from languages import has_sr_support



# ----------------- PAGE CONFIG -----------------

st.set_page_config(
    page_title="Multimodal AI Medical Translator",
    page_icon="🌐",
    layout="wide"
)

st.title("🌐 Multimodal AI Medical Translator")
st.caption("For doctors and rural patients – voice, text & image translation across 100+ languages")

languages = get_language_list()

tabs = st.tabs(["🗣 Speech", "📝 Text", "🖼 Image"])


# ----------------- SPEECH TAB -----------------

with tabs[0]:
    st.subheader("Speech to Speech Translation")

    col1, col2 = st.columns(2)

    # -------- LEFT: SOURCE / PATIENT --------
    with col1:
        st.markdown("#### Source (Patient)")
        src_lang = st.selectbox(
            "Patient Language",
            languages,
            index=languages.index("English") if "English" in languages else 0,
            key="src_lang_speech"
        )

        st.markdown("**Option 1 – Upload audio file (WAV only)**")
        uploaded_audio = st.file_uploader(
            "Upload patient audio file",
            type=["wav"],
            key="upload_audio"
        )

        st.markdown("---")
        st.markdown("**Option 2 – Record using microphone**")

        # st_audiorec shows mic buttons and returns WAV bytes when recording stops
        wav_audio_data = st_audiorec()

        recorded_path = None
        if wav_audio_data is not None:
            st.success("Recorded audio captured.")
            # playback recorded audio
            st.audio(wav_audio_data, format="audio/wav")

            # save WAV bytes to a temp file so speech_to_text can use it
            tmp_rec = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            tmp_rec.write(wav_audio_data)
            tmp_rec.flush()
            tmp_rec.close()
            recorded_path = tmp_rec.name

    # -------- RIGHT: TARGET / DOCTOR --------
    with col2:
        st.markdown("#### Target (Doctor)")
        tgt_lang = st.selectbox(
            "Doctor Language",
            languages,
            index=languages.index("Hindi") if "Hindi" in languages else 0,
            key="tgt_lang_speech"
        )

    # -------- TRANSLATE BUTTON --------
    if st.button("Translate Speech", type="primary", key="btn_speech"):
        temp_uploaded_path = None
        audio_path = None

        # Priority: uploaded file > microphone recording
        if uploaded_audio is not None:
            tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
            tmp.write(uploaded_audio.read())
            tmp.flush()
            tmp.close()
            temp_uploaded_path = tmp.name
            audio_path = temp_uploaded_path
        elif recorded_path is not None:
            audio_path = recorded_path

        if audio_path is None:
            st.error("Please upload an audio file OR record using your microphone.")
        elif not has_sr_support(src_lang):
            st.error(
                f"Speech recognition for '{src_lang}' is not configured. "
                "Please use the Text tab for this language, or choose a supported language for microphone input."
            )
        else:
            with st.spinner("Processing audio..."):
                try:
                    # 1) Speech -> Text
                    source_text = speech_to_text(audio_path, source_language_name=src_lang)

                    # 2) Text -> Translated Text
                    translated_text = translate_text(source_text, src_lang, tgt_lang)

                    # 3) Translated Text -> Speech
                    tts_path = text_to_speech_file(translated_text, tgt_lang)

                    st.success("Done!")

                    st.markdown("##### Recognized Patient Speech")
                    st.write(source_text or "(Could not recognize speech)")

                    st.markdown("##### Translated for Doctor")
                    st.write(translated_text)

                    st.markdown("##### Audio (Doctor side)")
                    with open(tts_path, "rb") as f:
                        audio_bytes = f.read()
                    st.audio(audio_bytes, format="audio/mp3")

                except Exception as e:
                    st.error(f"Error while translating speech: {e}")
                finally:
                    # clean up temporary files
                    if temp_uploaded_path:
                        cleanup_temp_file(temp_uploaded_path)
                    if recorded_path:
                        cleanup_temp_file(recorded_path)
                    if 'tts_path' in locals():
                        cleanup_temp_file(tts_path)


# ----------------- TEXT TAB -----------------

with tabs[1]:
    st.subheader("Text to Text + Speech Translation")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### Source Text")
        src_lang_txt = st.selectbox(
            "Source Language",
            languages,
            index=languages.index("English") if "English" in languages else 0,
            key="src_lang_txt"
        )
        src_text = st.text_area("Enter text", height=150)

    with col2:
        st.markdown("#### Target Text")
        tgt_lang_txt = st.selectbox(
            "Target Language",
            languages,
            index=languages.index("Hindi") if "Hindi" in languages else 0,
            key="tgt_lang_txt"
        )

    col3, col4 = st.columns([1, 1])

    with col3:
        if st.button("Translate Text", type="primary", key="btn_text"):
            if not src_text.strip():
                st.error("Please enter some text.")
            else:
                with st.spinner("Translating..."):
                    translated_text = translate_text(src_text, src_lang_txt, tgt_lang_txt)
                    st.markdown("##### Translated Text")
                    st.write(translated_text)
                    st.session_state["last_translated_text"] = translated_text
                    st.session_state["last_tgt_lang_txt"] = tgt_lang_txt

    with col4:
        if st.button("Play as Audio", key="btn_text_tts"):
            if "last_translated_text" not in st.session_state:
                st.error("Translate some text first.")
            else:
                with st.spinner("Generating speech..."):
                    try:
                        tts_path = text_to_speech_file(
                            st.session_state["last_translated_text"],
                            st.session_state["last_tgt_lang_txt"]
                        )
                        with open(tts_path, "rb") as f:
                            audio_bytes = f.read()
                        st.audio(audio_bytes, format="audio/mp3")
                    except Exception as e:
                        st.error(f"TTS error: {e}")
                    finally:
                        if 'tts_path' in locals():
                            cleanup_temp_file(tts_path)


# ----------------- IMAGE TAB -----------------

with tabs[2]:
    st.subheader("Image (Prescription/Report) to Text Translation")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### Source Image")
        src_lang_img = st.selectbox(
            "Language in Image",
            languages,
            index=languages.index("English") if "English" in languages else 0,
            key="src_lang_img"
        )
        img_file = st.file_uploader("Upload image (jpg, png)", type=["jpg", "jpeg", "png"])

    with col2:
        st.markdown("#### Target Language")
        tgt_lang_img = st.selectbox(
            "Translate To",
            languages,
            index=languages.index("Hindi") if "Hindi" in languages else 0,
            key="tgt_lang_img"
        )

    if st.button("Extract & Translate Image", type="primary", key="btn_image"):
        if not img_file:
            st.error("Please upload an image.")
        else:
            with st.spinner("Running OCR and translation..."):
                try:
                    image = Image.open(img_file).convert("RGB")
                    extracted_text, raw = ocr_image(image, src_lang_img)

                    st.markdown("##### Extracted Text from Image")
                    if extracted_text.strip():
                        st.write(extracted_text)

                        st.markdown("##### Translated Text")
                        translated_text = translate_text(extracted_text, src_lang_img, tgt_lang_img)
                        st.write(translated_text)

                        st.session_state["img_translated_text"] = translated_text
                        st.session_state["img_tgt_lang"] = tgt_lang_img
                    else:
                        st.warning("No readable text found in the image.")

                except Exception as e:
                    st.error(f"OCR/translation error: {e}")

    if st.button("Play Translated Image Text", key="btn_image_tts"):
        if "img_translated_text" not in st.session_state:
            st.error("Run image translation first.")
        else:
            with st.spinner("Generating audio..."):
                try:
                    tts_path = text_to_speech_file(
                        st.session_state["img_translated_text"],
                        st.session_state["img_tgt_lang"]
                    )
                    with open(tts_path, "rb") as f:
                        audio_bytes = f.read()
                    st.audio(audio_bytes, format="audio/mp3")
                except Exception as e:
                    st.error(f"TTS error: {e}")
                finally:
                    if 'tts_path' in locals():
                        cleanup_temp_file(tts_path)
