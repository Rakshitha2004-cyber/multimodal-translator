# stt.py
# stt.py  (new version without Whisper)

import speech_recognition as sr
from languages import code_for_sr


def speech_to_text(audio_path: str, source_language_name: str | None = None) -> str:
    """
    Convert speech audio file (.wav) to text using Google Speech Recognition.
    Does NOT require ffmpeg.
    """
    recognizer = sr.Recognizer()

    # choose language code
    if source_language_name:
        lang_code = code_for_sr(source_language_name)
    else:
        lang_code = "en-IN"  # default

    with sr.AudioFile(audio_path) as source:
        audio_data = recognizer.record(source)

    try:
        text = recognizer.recognize_google(audio_data, language=lang_code)
    except sr.UnknownValueError:
        # audio could not be understood
        text = ""
    except sr.RequestError as e:
        # network / API error
        raise RuntimeError(f"Speech recognition service error: {e}")

    return text.strip()
