# translate.py

from deep_translator import GoogleTranslator
from languages import code_for_googletrans

def translate_text(text: str, source_language_name: str, target_language_name: str) -> str:
    if not text:
        return ""

    src_code = code_for_googletrans(source_language_name)
    tgt_code = code_for_googletrans(target_language_name)

    translator = GoogleTranslator(source=src_code, target=tgt_code)
    translated = translator.translate(text)
    return translated
