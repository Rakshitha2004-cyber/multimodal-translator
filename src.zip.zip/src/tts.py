# tts.py

from gtts import gTTS
from languages import code_for_gtts
import tempfile
import os

def text_to_speech_file(text: str, language_name: str) -> str:
    """
    Convert text to speech and return a path to a temporary mp3 file.
    """
    if not text:
        raise ValueError("Empty text for TTS")

    lang_code = code_for_gtts(language_name)
    tts = gTTS(text=text, lang=lang_code)

    tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
    tmp_file.close()  # Close so gTTS can write
    tts.save(tmp_file.name)

    return tmp_file.name

def cleanup_temp_file(path: str):
    try:
        os.remove(path)
    except OSError:
        pass
